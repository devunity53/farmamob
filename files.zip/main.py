# ============================================================
#  main.py — Interface graphique + point d'entrée
#  Lance : python main.py
# ============================================================

import tkinter as tk
from tkinter import ttk, messagebox
import threading
import time

import config
import events
import actions
import cycle

# ============================================================
#  Helpers UI
# ============================================================

def _champ_float(parent, label, valeur, row, col=0):
    """Retourne un tuple (frame, StringVar) pour un champ numérique."""
    tk.Label(parent, text=label, anchor="w").grid(
        row=row, column=col, sticky="w", padx=6, pady=2)
    var = tk.StringVar(value=str(valeur))
    e = tk.Entry(parent, textvariable=var, width=8)
    e.grid(row=row, column=col + 1, sticky="w", padx=4)
    return var


# ============================================================
#  Fenêtre principale
# ============================================================

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("🧟 Ferme à mobs — Minecraft")
        self.resizable(False, False)
        self._construire_ui()
        self._demarrer_compte_a_rebours()

        # Notifier l'interface quand l'état de pause change
        events.on_changement_etat(self._maj_etat)

        # Démarrer l'écoute clavier
        events.demarrer_ecoute_clavier()

        # Démarrer les notifications d'inventaire
        self._demarrer_notifications()

    # ---- Construction ----

    def _construire_ui(self):
        pad = {"padx": 10, "pady": 6}

        # === En-tête ===
        hdr = tk.Frame(self, bg="#1a1a2e")
        hdr.pack(fill="x")
        tk.Label(hdr, text="⛏ Ferme à mobs", font=("Segoe UI", 14, "bold"),
                 bg="#1a1a2e", fg="#e0e0ff").pack(pady=8)

        # === Panneau paramètres ===
        frm = ttk.LabelFrame(self, text="Paramètres", padding=8)
        frm.pack(fill="x", **pad)

        self.v_cycle_min  = _champ_float(frm, "Durée cycle min (s)",     config.DUREE_CYCLE_MIN,  0)
        self.v_cycle_max  = _champ_float(frm, "Durée cycle max (s)",     config.DUREE_CYCLE_MAX,  1)
        self.v_pause_min  = _champ_float(frm, "Pause auto min (s)",      config.DUREE_PAUSE_MIN,  2)
        self.v_pause_max  = _champ_float(frm, "Pause auto max (s)",      config.DUREE_PAUSE_MAX,  3)
        self.v_arret_int  = _champ_float(frm, "Arrêt long toutes (min)", config.INTERVALLE_ARRET_LONG_MINUTES, 4)
        self.v_arret_dur  = _champ_float(frm, "Durée arrêt long (s)",    config.DUREE_ARRET_LONG_SECONDES,     5)
        self.v_notif      = _champ_float(frm, "Notif. inventaire (s)",   config.INTERVALLE_NOTIFICATION,       6)
        self.v_demarrage  = _champ_float(frm, "Délai démarrage (s)",     config.DELAI_DEMARRAGE,  7)

        ttk.Button(frm, text="Appliquer les paramètres",
                   command=self._appliquer_parametres).grid(
            row=8, column=0, columnspan=2, pady=(8, 2), sticky="ew")

        # === Panneau contrôle ===
        ctrl = ttk.LabelFrame(self, text="Contrôle", padding=8)
        ctrl.pack(fill="x", **pad)

        self.lbl_etat = tk.Label(ctrl, text="⏹ Arrêtée",
                                 font=("Segoe UI", 11, "bold"), fg="#888")
        self.lbl_etat.pack()

        self.lbl_compte = tk.Label(ctrl, text="", font=("Segoe UI", 9), fg="#555")
        self.lbl_compte.pack()

        btn_frame = tk.Frame(ctrl)
        btn_frame.pack(pady=6)

        self.btn_lancer = ttk.Button(btn_frame, text="▶  Lancer",
                                     command=self._lancer, width=14)
        self.btn_lancer.grid(row=0, column=0, padx=4)

        self.btn_pause = ttk.Button(btn_frame, text="⏸  Pause",
                                    command=events.basculer_pause,
                                    state="disabled", width=14)
        self.btn_pause.grid(row=0, column=1, padx=4)

        self.btn_stop = ttk.Button(btn_frame, text="⏹  Arrêter",
                                   command=self._arreter,
                                   state="disabled", width=14)
        self.btn_stop.grid(row=0, column=2, padx=4)

        tk.Label(ctrl, text=f"Raccourci clavier : [  {config.TOUCHE_PAUSE}  ] pour pause/reprise",
                 font=("Segoe UI", 8), fg="#999").pack()

        # === Journal ===
        log_frm = ttk.LabelFrame(self, text="Journal", padding=4)
        log_frm.pack(fill="both", expand=True, **pad)

        self.log = tk.Text(log_frm, height=10, state="disabled",
                           font=("Consolas", 8), bg="#0d0d1a", fg="#c8f0c8",
                           insertbackground="white")
        scr = ttk.Scrollbar(log_frm, command=self.log.yview)
        self.log.configure(yscrollcommand=scr.set)
        self.log.pack(side="left", fill="both", expand=True)
        scr.pack(side="right", fill="y")

        # Rediriger print vers le journal
        import sys
        sys.stdout = _Redirecteur(self._ajouter_log)

    # ---- Paramètres ----

    def _appliquer_parametres(self):
        try:
            config.DUREE_CYCLE_MIN                = float(self.v_cycle_min.get())
            config.DUREE_CYCLE_MAX                = float(self.v_cycle_max.get())
            config.DUREE_PAUSE_MIN                = float(self.v_pause_min.get())
            config.DUREE_PAUSE_MAX                = float(self.v_pause_max.get())
            config.INTERVALLE_ARRET_LONG_MINUTES  = float(self.v_arret_int.get())
            config.DUREE_ARRET_LONG_SECONDES      = float(self.v_arret_dur.get())
            config.INTERVALLE_NOTIFICATION        = float(self.v_notif.get())
            config.DELAI_DEMARRAGE                = float(self.v_demarrage.get())
            print("✅ Paramètres appliqués")
        except ValueError:
            messagebox.showerror("Erreur", "Valeurs invalides (nombres décimaux attendus).")

    # ---- Lancer / Arrêter ----

    def _lancer(self):
        self._appliquer_parametres()
        delai = int(config.DELAI_DEMARRAGE)
        self.btn_lancer.configure(state="disabled")
        self._demarrer_compte_a_rebours(delai, callback=self._demarrer_ferme)

    def _demarrer_ferme(self):
        actions.cliquer_en_continu()
        cycle.demarrer()
        self.btn_pause.configure(state="normal")
        self.btn_stop.configure(state="normal")
        self._maj_etat()
        print("🚀 Ferme démarrée !")

    def _arreter(self):
        cycle.arreter()
        self.btn_lancer.configure(state="normal")
        self.btn_pause.configure(state="disabled")
        self.btn_stop.configure(state="disabled")
        self.lbl_etat.configure(text="⏹ Arrêtée", fg="#888")

    # ---- Compte à rebours ----

    def _demarrer_compte_a_rebours(self, secondes=0, callback=None):
        if secondes <= 0:
            if callback:
                callback()
            return
        self.lbl_compte.configure(
            text=f"Démarrage dans {secondes} s — clique sur Minecraft !")
        self.after(1000, lambda: self._demarrer_compte_a_rebours(secondes - 1, callback))

    # ---- Mise à jour état ----

    def _maj_etat(self):
        if not cycle.est_actif():
            return
        if events.en_pause_manuelle:
            self.lbl_etat.configure(text="⏸ Pause manuelle", fg="#f0c040")
            self.btn_pause.configure(text="▶  Reprendre")
        elif not events.pause_auto.is_set():
            self.lbl_etat.configure(text="⏸ Pause auto", fg="#80c0ff")
            self.btn_pause.configure(text="⏸  Pause")
        else:
            self.lbl_etat.configure(text="▶ En cours", fg="#60e060")
            self.btn_pause.configure(text="⏸  Pause")

    # ---- Journal ----

    def _ajouter_log(self, texte):
        self.log.configure(state="normal")
        self.log.insert("end", texte)
        self.log.see("end")
        self.log.configure(state="disabled")

    # ---- Notifications inventaire ----

    def _demarrer_notifications(self):
        def _boucle():
            while True:
                time.sleep(config.INTERVALLE_NOTIFICATION)
                if cycle.est_actif():
                    try:
                        from plyer import notification
                        notification.notify(
                            title="Minecraft",
                            message="Vide ton inventaire !",
                            app_name="Ferme à mobs",
                            timeout=10
                        )
                    except Exception:
                        pass
                    print("🔔 Notification : Vide ton inventaire !")
        threading.Thread(target=_boucle, daemon=True).start()


# ============================================================
#  Redirecteur stdout → journal UI
# ============================================================

class _Redirecteur:
    def __init__(self, fn_ecrire):
        self._fn = fn_ecrire
        self._buffer = ""

    def write(self, texte):
        self._buffer += texte
        if "\n" in self._buffer:
            lignes = self._buffer.split("\n")
            for ligne in lignes[:-1]:
                self._fn(ligne + "\n")
            self._buffer = lignes[-1]

    def flush(self):
        pass


# ============================================================
#  Point d'entrée
# ============================================================

if __name__ == "__main__":
    app = App()
    app.mainloop()
