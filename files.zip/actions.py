# ============================================================
#  actions.py — Toutes les actions pyautogui
#  Chaque fonction est indépendante et testable séparément
# ============================================================

import time
import random
import pyautogui
import winsound  # Windows uniquement ; voir commentaire bas de fichier

import config
import events

pyautogui.FAILSAFE = True


# ---- Clic gauche continu ----

def cliquer_en_continu():
    """Thread : clique en boucle tant que pas en pause."""
    import threading
    def _boucle():
        while True:
            events.attendre_autorisation()
            pyautogui.click(button="left")
            time.sleep(random.uniform(config.INTERVALLE_CLIC_MIN,
                                      config.INTERVALLE_CLIC_MAX))
    threading.Thread(target=_boucle, daemon=True).start()


# ---- Mouvement avec touche maintenue ----

def maintenir_touche(touche, duree):
    """
    Maintient 'touche' pendant 'duree' secondes.
    Relâche immédiatement si une pause se déclenche.
    """
    temps_restant = duree
    while temps_restant > 0:
        events.attendre_autorisation()
        pyautogui.keyDown(touche)
        while temps_restant > 0:
            if events.est_en_pause():
                pyautogui.keyUp(touche)
                break
            time.sleep(0.05)
            temps_restant -= 0.05
        pyautogui.keyUp(touche)


# ---- Séquence de pause automatique ----

def executer_pause_auto(duree_pause):
    """
    Séquence complète de la pause entre les cycles :
      scroll bas → clic droit 4 s → scroll haut → attendre fin de pause
    """
    debut = time.time()

    # Attendre 1 seconde
    _attendre_avec_pause(1.0, debut)

    # Scroll vers le bas
    pyautogui.scroll(-1)
    time.sleep(random.uniform(0.2, 0.4))

    # Clic droit maintenu 4 secondes
    pyautogui.mouseDown(button="right")
    debut_clic = time.time()
    while time.time() - debut_clic < 4:
        events.reprendre.wait()
        time.sleep(0.05)
    pyautogui.mouseUp(button="right")

    time.sleep(random.uniform(0.2, 0.4))

    # Scroll vers le haut
    pyautogui.scroll(1)

    # Attendre la fin de la pause totale
    _attendre_avec_pause(duree_pause, debut)


def _attendre_avec_pause(duree, debut):
    """Attend jusqu'à ce que 'duree' secondes soient écoulées depuis 'debut',
    en respectant les pauses manuelles."""
    while time.time() - debut < duree:
        events.reprendre.wait()
        time.sleep(0.05)


# ---- Arrêt long (toutes les N minutes) ----

def executer_arret_long(duree_secondes):
    """
    Arrêt long : bip sonore, pause complète, puis reprise.
    """
    print(f"\n🔔 Arrêt long : pause de {duree_secondes:.0f} secondes")
    _bip()
    events.mettre_en_pause_auto()
    time.sleep(duree_secondes)
    events.reprendre_auto()
    print("▶ Reprise après arrêt long")


def _bip():
    """Émet un bip système (Windows). Adapte si tu es sous Linux/Mac."""
    try:
        # Windows
        winsound.Beep(1000, 500)   # 1000 Hz, 500 ms
        time.sleep(0.2)
        winsound.Beep(1000, 500)
    except Exception:
        # Fallback : caractère BEL dans le terminal
        print("\a")
