# ============================================================
#  config.py — Tous les paramètres de la ferme à mobs
#  Modifie ces valeurs ou utilise l'interface graphique (main.py)
# ============================================================

# --- Durée totale d'un cycle de fonctionnement (secondes) ---
DUREE_CYCLE_MIN = 12.0
DUREE_CYCLE_MAX = 15.0

# --- Durée de la pause automatique entre chaque cycle (secondes) ---
DUREE_PAUSE_MIN = 8.0
DUREE_PAUSE_MAX = 15.0

# --- Arrêt long toutes les X minutes ---
INTERVALLE_ARRET_LONG_MINUTES = 13.0   # toutes les 13 minutes
DUREE_ARRET_LONG_SECONDES    = 180.0  # pause de 3 minutes

# --- Touche de pause / reprise manuelle ---
TOUCHE_PAUSE = "+"

# --- Mouvements gauche / droite ---
DUREE_MOUVEMENT_MIN = 1.8   # secondes
DUREE_MOUVEMENT_MAX = 2.2

# --- Délais entre les mouvements ---
DELAI_APRES_GAUCHE_MIN = 0.3
DELAI_APRES_GAUCHE_MAX = 0.7
DELAI_APRES_DROITE_MIN = 0.2
DELAI_APRES_DROITE_MAX = 0.5

# --- Clics gauche continus ---
INTERVALLE_CLIC_MIN = 0.05
INTERVALLE_CLIC_MAX = 0.15

# --- Notification inventaire (secondes) ---
INTERVALLE_NOTIFICATION = 60

# --- Délai au démarrage (secondes) ---
DELAI_DEMARRAGE = 10
