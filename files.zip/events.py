# ============================================================
#  events.py — Gestion des états pause / reprise
#  Deux événements indépendants :
#    · reprendre   → pause manuelle (touche +)
#    · pause_auto  → pause automatique entre les cycles
# ============================================================

import threading
import keyboard
import config

# ---- Événements ----
reprendre  = threading.Event()
pause_auto = threading.Event()
reprendre.set()
pause_auto.set()

# ---- État lisible ----
en_pause_manuelle = False

# ---- Callbacks optionnels (ex. mise à jour de l'interface) ----
_callbacks_changement = []

def on_changement_etat(fn):
    """Enregistre une fonction appelée à chaque changement d'état."""
    _callbacks_changement.append(fn)

def _notifier():
    for fn in _callbacks_changement:
        try:
            fn()
        except Exception:
            pass

# ---- API publique ----

def est_en_pause():
    return en_pause_manuelle or not pause_auto.is_set()

def mettre_en_pause_manuelle():
    global en_pause_manuelle
    en_pause_manuelle = True
    reprendre.clear()
    print("⏸ Pause manuelle")
    _notifier()

def reprendre_manuel():
    global en_pause_manuelle
    en_pause_manuelle = False
    reprendre.set()
    print("▶ Reprise")
    _notifier()

def basculer_pause():
    if en_pause_manuelle:
        reprendre_manuel()
    else:
        mettre_en_pause_manuelle()

def mettre_en_pause_auto():
    pause_auto.clear()
    _notifier()

def reprendre_auto():
    pause_auto.set()
    _notifier()

def attendre_autorisation():
    """Bloque tant que l'une ou l'autre des pauses est active."""
    reprendre.wait()
    pause_auto.wait()

# ---- Écoute clavier (thread démon) ----

def _ecouter_clavier():
    while True:
        event = keyboard.read_event(suppress=False)
        if event.event_type == keyboard.KEY_DOWN and event.name == config.TOUCHE_PAUSE:
            basculer_pause()

def demarrer_ecoute_clavier():
    t = threading.Thread(target=_ecouter_clavier, daemon=True)
    t.start()
