# ============================================================
#  cycle.py — Logique principale du cycle de la ferme
#  Tourne dans son propre thread lancé depuis main.py
# ============================================================

import time
import random
import threading

import config
import events
import actions

_en_cours = False
_thread   = None


def demarrer():
    global _en_cours, _thread
    if _en_cours:
        return
    _en_cours = True
    _thread = threading.Thread(target=_boucle_principale, daemon=True)
    _thread.start()


def arreter():
    global _en_cours
    _en_cours = False
    # Débloquer les attentes pour que le thread puisse se terminer proprement
    events.reprendre.set()
    events.pause_auto.set()


def est_actif():
    return _en_cours


# ---- Boucle principale ----

def _boucle_principale():
    numero_cycle   = 0
    debut_session  = time.time()

    while _en_cours:

        # ---- Vérifier si c'est l'heure de l'arrêt long ----
        temps_ecoule = (time.time() - debut_session) / 60.0
        if temps_ecoule >= config.INTERVALLE_ARRET_LONG_MINUTES:
            actions.executer_arret_long(config.DUREE_ARRET_LONG_SECONDES)
            debut_session = time.time()   # reset le compteur

        if not _en_cours:
            break

        # ---- Phase de fonctionnement ----
        numero_cycle += 1
        duree_cycle   = random.uniform(config.DUREE_CYCLE_MIN, config.DUREE_CYCLE_MAX)

        print(f"\n▶ Cycle {numero_cycle} — fonctionnement {duree_cycle:.1f} s")

        events.reprendre_auto()
        debut = time.time()

        while _en_cours and time.time() - debut < duree_cycle:
            events.attendre_autorisation()

            actions.maintenir_touche("q", random.uniform(config.DUREE_MOUVEMENT_MIN,
                                                         config.DUREE_MOUVEMENT_MAX))
            events.attendre_autorisation()
            time.sleep(random.uniform(config.DELAI_APRES_GAUCHE_MIN,
                                      config.DELAI_APRES_GAUCHE_MAX))

            actions.maintenir_touche("d", random.uniform(config.DUREE_MOUVEMENT_MIN,
                                                         config.DUREE_MOUVEMENT_MAX))
            events.attendre_autorisation()
            time.sleep(random.uniform(config.DELAI_APRES_DROITE_MIN,
                                      config.DELAI_APRES_DROITE_MAX))

        if not _en_cours:
            break

        # ---- Phase de pause automatique ----
        duree_pause = random.uniform(config.DUREE_PAUSE_MIN, config.DUREE_PAUSE_MAX)
        print(f"⏸ Pause auto — {duree_pause:.1f} s")

        events.mettre_en_pause_auto()
        actions.executer_pause_auto(duree_pause)

    print("\n⏹ Ferme arrêtée.")
