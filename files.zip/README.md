# 🧟 Ferme à mobs — Minecraft

## Structure des fichiers

```
mob_farm/
├── config.py   → Tous les paramètres (durées, intervalles...)
├── events.py   → Gestion pause / reprise (manuelle & auto)
├── actions.py  → Actions pyautogui (clics, touches, bips...)
├── cycle.py    → Logique du cycle principal
└── main.py     → Interface graphique + point d'entrée
```

## Lancement

```bash
pip install pyautogui keyboard plyer
python main.py
```

## Utilisation

1. Lance `main.py`
2. Ajuste les paramètres dans l'interface si besoin, clique **Appliquer**
3. Clique **▶ Lancer** — tu as le délai de démarrage pour cliquer sur Minecraft
4. **⏸ Pause / reprise** : bouton dans l'interface **ou** touche `+` sur le clavier

## Fonctionnement

| Phase | Durée |
|---|---|
| Cycle (q/d + clics) | 12–15 s (configurable) |
| Pause auto (scroll + clic droit) | 8–15 s (configurable) |
| **Arrêt long** (toutes les 13 min) | **3 min + 2 bips** |

## Modifier les paramètres

- **Via l'interface** : modifie les champs et clique *Appliquer les paramètres*
- **Via le code** : ouvre `config.py` et change les valeurs, les commentaires expliquent chaque option
